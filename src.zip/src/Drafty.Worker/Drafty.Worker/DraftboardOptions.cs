namespace Drafty.Worker;

public class DraftboardOptions
{
    public int NumberOfTeams { get; set; }
    public int NumberOfRounds { get; set; }
}