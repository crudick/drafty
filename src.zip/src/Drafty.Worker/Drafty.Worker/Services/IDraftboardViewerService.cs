using Drafty.Common;

namespace Drafty.Worker.Services;

public interface IDraftboardViewerService
{
    DraftBoard GetDraftBoard();
}