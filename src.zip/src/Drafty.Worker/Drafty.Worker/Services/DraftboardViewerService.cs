using Drafty.Common;
using Microsoft.Extensions.Options;
using Tesseract;

namespace Drafty.Worker.Services;

public class DraftboardViewerService : IDraftboardViewerService
{
    private readonly DraftboardOptions _options;
    private readonly ILogger<DraftboardViewerService> _logger;
    public DraftboardViewerService(IOptions<DraftboardOptions> options, ILogger<DraftboardViewerService> logger)
    {
        _logger = logger;
        _options = options.Value;
    }
    
    public DraftBoard GetDraftBoard()
    {
        var imagePath = GetImageOfDraftBoard();
        var rawDraftBoardData = GetRawDataFromDraftBoardImage(imagePath);
        var draftBoard = ParseDraftBoardData(rawDraftBoardData);
        return draftBoard;
    }

    public string GetImageOfDraftBoard()
    {
        return "./../../tessdata/draftboard.jpeg";
    }

    public string GetRawDataFromDraftBoardImage(string imagePath)
    {
        using var engine = new TesseractEngine(@"./../../tessdata/", "eng", EngineMode.Default);
        using var img = Pix.LoadFromFile(imagePath);
        using var page = engine.Process(img);
        var rawString = page.GetText();
        _logger.LogDebug(rawString);
        return rawString;
    } 
    
    public DraftBoard ParseDraftBoardData(string rawDraftBoardData)
    {
        var picks = new List<Pick>();
        var teams = new List<FantasyTeam>();
        var players = new List<Player>();

        var playerNames = rawDraftBoardData.Split("|").ToList();
        
        
        
        var draftBoard = new DraftBoard(picks, teams, 0, 0, 0, 0, 0, false);


        return draftBoard;
    }
}