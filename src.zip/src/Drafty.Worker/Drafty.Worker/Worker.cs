using Drafty.Worker.Services;

namespace Drafty.Worker;

public class Worker : BackgroundService
{
    private readonly ILogger<Worker> _logger;
    private readonly IDraftboardViewerService _draftboardViewerService;

    public Worker(ILogger<Worker> logger, IDraftboardViewerService draftboardViewerService)
    {
        _logger = logger;
        _draftboardViewerService = draftboardViewerService;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            if (_logger.IsEnabled(LogLevel.Information))
            {
                _logger.LogInformation("Worker running at: {time}", DateTimeOffset.Now);
            }

            _draftboardViewerService.GetDraftBoard();
            await Task.Delay(1000, stoppingToken);
        }
    }
    
    
}