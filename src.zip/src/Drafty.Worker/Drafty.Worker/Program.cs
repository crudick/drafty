using Drafty.Worker;
using Drafty.Worker.Services;

var builder = Host.CreateApplicationBuilder(args);
builder.Services.Configure<DraftboardOptions>(builder.Configuration.GetSection("DraftboardOptions"));
builder.Services.AddSingleton<IDraftboardViewerService, DraftboardViewerService>();
builder.Services.AddHostedService<Worker>();

var host = builder.Build();
host.Run();