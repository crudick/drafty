namespace Drafty.Common.Enums;

public enum PositionEnum
{
    Quarterback,
    RunningBack,
    WideReceiver,
    TightEnd,
    Kicker,
    Defense
}