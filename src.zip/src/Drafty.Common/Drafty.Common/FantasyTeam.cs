namespace Drafty.Common;

public record FantasyTeam(string TeamName, Roster Roster);