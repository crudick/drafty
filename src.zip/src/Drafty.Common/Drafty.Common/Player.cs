using Drafty.Common.Enums;

namespace Drafty.Common;

public record Player(string PlayerName, PositionEnum Position, string NflTeam, int Rank, int ByeWeek, bool IsAvailable);