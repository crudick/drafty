namespace Drafty.Common;

public record Roster(List<Player> QuarterBacks, List<Player> RunningBacks, List<Player> WideReceivers, List<Player> TightEnds, List<Player> Defenses, List<Player> Kickers);