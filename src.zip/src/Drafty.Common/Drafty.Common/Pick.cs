﻿namespace Drafty.Common;

public record Pick(int PickNumber, string TeamName, int Round, Player player);