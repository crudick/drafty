namespace Drafty.Common;

public record DraftBoard(List<Pick> Picks, List<FantasyTeam> Teams, int CurrentRound, int CurrentPick, int TotalPicks, int TotalRounds, int TotalTeams, bool IsDraftComplete);